
public class TestBook {

	public static void main(String[] args) {

	      Author ebenTech = new Author("ebenezer", "eben@eatechnologies.tech", 'm');
	      System.out.println(ebenTech);  

	      
	      Book codingBook = new Book("Coding for Begineers", ebenTech, 99.99, 99);
	      System.out.println(codingBook);  
	      
	      codingBook.setPrice(8.88);
	      codingBook.setQty(88);
	      System.out.println("name is: " + codingBook.getName());
	      System.out.println("price is: " + codingBook.getPrice());
	      
	      System.out.println("qty is: " + codingBook.getQty());
	      
	      System.out.println("author is: " + codingBook.getAuthor());  
	      System.out.println("author's name is: " + codingBook.getAuthor().getName());
	      
	      System.out.println("author's email is: " + codingBook.getAuthor().getEmail());
	      
	      System.out.println("author's gender is: " + codingBook.getAuthor().getGender());
	      

	      
	      Book moreCodingBook = new Book("Coding for beginers"),
	            new Author("Max", "max@eben.com", 'm'), 
	            
	      System.out.println(moreCodingBook);  
	      
	   }
	}

	


