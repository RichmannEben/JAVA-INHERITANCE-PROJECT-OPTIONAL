
public class TestSuthor {

	public static void main(String[] args) {
		 Author ebenTech = new Author("Ebenezer", "eben@eatechnologies.tech", 'm');
	      System.out.println(ebenTech);  

	      
	      ebenTech.setEmail("ebenez.gmpegroup.com");
	      System.out.println(ebenTech);
	     
	      System.out.println("name is: " + ebenTech.getName());
	      System.out.println("gender is: " + ebenTech.getGender());
	      
	      System.out.println("email is: " + ebenTech.getEmail());
	      
	

	}

}
